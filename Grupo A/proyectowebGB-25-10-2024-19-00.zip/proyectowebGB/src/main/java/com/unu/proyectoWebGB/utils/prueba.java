package com.unu.proyectoWebGB.utils;

import com.unu.proyectoWebGB.models.Conexion;

public class prueba {

	public static void main(String[] args) {

		Conexion c = new Conexion();
		c.abrirConexion();
		c.cerrarConexion();

	}

}
